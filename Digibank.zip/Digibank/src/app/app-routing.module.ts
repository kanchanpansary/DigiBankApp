import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TransfersComponent } from './transfers/transfers.component';
import { DetailsComponent } from './details/details.component';

const routes: Routes = [
  {path:'home', component: HomeComponent, canActivate:[AuthGuard]},
  {path:'dashboard', component: DashboardComponent, canActivate:[AuthGuard]},
  {path:'details', component: DetailsComponent, canActivate:[AuthGuard]},
  {path:'transfers', component: TransfersComponent, canActivate:[AuthGuard]},
  {path:'', component: LoginComponent  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
