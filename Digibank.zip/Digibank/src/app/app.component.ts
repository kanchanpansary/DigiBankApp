import { Component, Output, Input ,OnInit} from '@angular/core';
import { AuthenticationService } from './service/authentication/authentication.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'login-page-demo';
ngOnInit(){
  console.log(this.authenticationService.usernameX +"jkshdkjas");
 
}
  constructor(public authenticationService: AuthenticationService){
    
  }

 public  usernameY:string=this.authenticationService.usernameX;

  logout(){
    this.authenticationService.logout();
    console.log(this.authenticationService.usernameX)
  }
}
