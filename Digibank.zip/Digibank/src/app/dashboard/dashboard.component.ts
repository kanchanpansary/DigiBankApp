import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../service/authentication/authentication.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(public authenticationService: AuthenticationService) { }
  public  usernameZ:string=this.authenticationService.usernameX;
  ngOnInit(): void {

  }

}
