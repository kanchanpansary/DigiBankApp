import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../service/authentication/authentication.service';
import { SignInData } from 'src/app/model/signInData'

import accounts from '../_files/accounts.json';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private authenticationService:AuthenticationService) { }

  ngOnInit(): void {
  console.log(this.authenticationService.usernameX)
  }
  public accountList:{name:string, accountNumber:string, accountType:string, balance:string}[] = accounts;
  public username:string=this.authenticationService.usernameX;

}
