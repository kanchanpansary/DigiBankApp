import { Injectable ,OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { SignInData } from 'src/app/model/signInData';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService  {


  private readonly mockedUser = new SignInData('kanchan@gmail.com','test123');
  private readonly mockedUserArray: {username:string, password:string}[]=[
    {'username':'kanchan','password':'test123'},
    {'username':'amit','password':'test123'},
    {'username':'daya','password':'test123'}
]
 
    
  isAuthenticated = false;
  usernameX='';
  constructor(private router: Router) { }


  authenticate(signInData:SignInData): boolean{
    this.usernameX =signInData.getEmail();
    if(this.checkCredentials(signInData)){
      this.isAuthenticated=true;
      this.router.navigate(['dashboard']);
      return true;
    }
    this.isAuthenticated=false;
    return false;
  }

  private checkCredentials(signInData: SignInData): boolean{
    
    return this.checkEmailPassword(signInData.getEmail(),signInData.getPassword());
  }

  
  private checkEmailPassword(email:string, password:string): boolean{
    for (let i = 0; i < 3; i++) {
      if(this.mockedUserArray[i].username===email && this.mockedUserArray[i].password===password){
        return true;
      }      
      }
      return false;
    }
 
  logout(){
    this.isAuthenticated=false;
    this.router.navigate(['']);
  }
}
